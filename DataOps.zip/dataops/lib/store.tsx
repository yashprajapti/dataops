"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import type { AgentId } from "./agents";
import { getSample, SAMPLE_DATASETS, type Row } from "./sample-data";
import { autoClean, profileDataset, type DatasetProfile } from "./analytics";
import type { ChartSpec } from "./local-engine";
import { uid } from "./utils";

export interface User {
  name: string;
  email: string;
  role: string;
  company: string;
  bio: string;
  location: string;
  avatarSeed: string;
  plan: "Starter" | "Pro" | "Enterprise";
  joined: number;
}

export interface Dataset {
  id: string;
  name: string;
  source: "sample" | "upload";
  sampleId?: string;
  rows?: Row[];
  createdAt: number;
  cleaned?: boolean;
  cleanLog?: string[];
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  agent: AgentId;
  content: string;
  sql?: string;
  result?: { columns: string[]; rows: Row[]; error?: string; ms?: number };
  chart?: ChartSpec;
  engine?: "gemini" | "local";
  ts: number;
}

export interface Settings {
  geminiKey: string;
  anomalyThreshold: number;
  emailAlerts: boolean;
  weeklyDigest: boolean;
  compactMode: boolean;
}

interface State {
  user: User | null;
  datasets: Dataset[];
  activeId: string | null;
  chats: Record<string, ChatMessage[]>;
  settings: Settings;
  usage: { queries: number; tokens: number };
}

const KEY = "dataops:v1";
const DEFAULT_SETTINGS: Settings = { geminiKey: "", anomalyThreshold: 3, emailAlerts: true, weeklyDigest: true, compactMode: false };
const EMPTY: State = { user: null, datasets: [], activeId: null, chats: {}, settings: DEFAULT_SETTINGS, usage: { queries: 0, tokens: 0 } };

function load(): State {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return EMPTY;
    const s = JSON.parse(raw);
    return { ...EMPTY, ...s, settings: { ...DEFAULT_SETTINGS, ...(s.settings || {}) } };
  } catch {
    return EMPTY;
  }
}

interface Ctx extends State {
  ready: boolean;
  login: (email: string, name?: string) => void;
  logout: () => void;
  updateUser: (u: Partial<User>) => void;
  addUpload: (name: string, rows: Row[]) => string;
  addSample: (sampleId: string) => string;
  removeDataset: (id: string) => void;
  setActive: (id: string) => void;
  cleanDataset: (id: string) => string[];
  pushMessage: (m: ChatMessage) => void;
  patchMessage: (agent: AgentId, id: string, patch: Partial<ChatMessage>) => void;
  clearChat: (agent: AgentId) => void;
  updateSettings: (s: Partial<Settings>) => void;
  trackUsage: (tokens: number) => void;
  resetAll: () => void;
}

const AppCtx = createContext<Ctx | null>(null);

/** Keep saved chat history small enough for localStorage */
const trimResult = (m: ChatMessage): ChatMessage => (m.result && m.result.rows.length > 200 ? { ...m, result: { ...m.result, rows: m.result.rows.slice(0, 200) } } : m);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<State>(EMPTY);
  const [ready, setReady] = useState(false);
  const memRows = useRef<Record<string, Row[]>>({});

  useEffect(() => {
    setState(load());
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
    } catch {
      // quota exceeded — keep large uploads in memory only
      try {
        const slim = { ...state, datasets: state.datasets.map((d) => (d.rows ? { ...d, rows: undefined } : d)) };
        state.datasets.forEach((d) => d.rows && (memRows.current[d.id] = d.rows));
        localStorage.setItem(KEY, JSON.stringify(slim));
      } catch {}
    }
  }, [state, ready]);

  const set = useCallback((fn: (s: State) => State) => setState((s) => fn(s)), []);

  const api: Ctx = useMemo(
    () => ({
      ...state,
      ready,
      login: (email, name) =>
        set((s) => {
          const existing = s.user && s.user.email === email ? s.user : null;
          const user: User = existing || {
            name: name || email.split("@")[0].replace(/[._]/g, " ").replace(/\b\w/g, (m) => m.toUpperCase()),
            email,
            role: "Data Analyst",
            company: "",
            bio: "",
            location: "India",
            avatarSeed: email,
            plan: "Starter",
            joined: Date.now(),
          };
          let datasets = s.datasets;
          let activeId = s.activeId;
          if (!datasets.length) {
            const d: Dataset = { id: uid("ds"), name: SAMPLE_DATASETS[0].file, source: "sample", sampleId: SAMPLE_DATASETS[0].id, createdAt: Date.now() };
            datasets = [d];
            activeId = d.id;
          }
          return { ...s, user, datasets, activeId };
        }),
      logout: () => set((s) => ({ ...s, user: null })),
      updateUser: (u) => set((s) => ({ ...s, user: s.user ? { ...s.user, ...u } : s.user })),
      addUpload: (name, rows) => {
        const id = uid("ds");
        set((s) => ({ ...s, datasets: [{ id, name, source: "upload", rows, createdAt: Date.now() }, ...s.datasets], activeId: id }));
        return id;
      },
      addSample: (sampleId) => {
        const sample = SAMPLE_DATASETS.find((d) => d.id === sampleId)!;
        const existing = state.datasets.find((d) => d.sampleId === sampleId && !d.cleaned);
        if (existing) {
          set((s) => ({ ...s, activeId: existing.id }));
          return existing.id;
        }
        const id = uid("ds");
        set((s) => ({ ...s, datasets: [{ id, name: sample.file, source: "sample", sampleId, createdAt: Date.now() }, ...s.datasets], activeId: id }));
        return id;
      },
      removeDataset: (id) =>
        set((s) => {
          const datasets = s.datasets.filter((d) => d.id !== id);
          return { ...s, datasets, activeId: s.activeId === id ? datasets[0]?.id ?? null : s.activeId };
        }),
      setActive: (id) => set((s) => ({ ...s, activeId: id })),
      cleanDataset: (id) => {
        const d = state.datasets.find((x) => x.id === id);
        if (!d) return [];
        const rows = datasetRows(d, memRows.current);
        const { rows: cleaned, log } = autoClean(rows, profileDataset(rows));
        const newId = uid("ds");
        const name = d.name.replace(/(\.csv)?$/i, "_cleaned.csv");
        set((s) => ({ ...s, datasets: [{ id: newId, name, source: "upload", rows: cleaned, createdAt: Date.now(), cleaned: true, cleanLog: log }, ...s.datasets], activeId: newId }));
        return log;
      },
      pushMessage: (m) => set((s) => ({ ...s, chats: { ...s.chats, [m.agent]: [...(s.chats[m.agent] || []), trimResult(m)].slice(-60) } })),
      patchMessage: (agent, id, patch) =>
        set((s) => ({ ...s, chats: { ...s.chats, [agent]: (s.chats[agent] || []).map((m) => (m.id === id ? trimResult({ ...m, ...patch }) : m)) } })),
      clearChat: (agent) => set((s) => ({ ...s, chats: { ...s.chats, [agent]: [] } })),
      updateSettings: (p) => set((s) => ({ ...s, settings: { ...s.settings, ...p } })),
      trackUsage: (tokens) => set((s) => ({ ...s, usage: { queries: s.usage.queries + 1, tokens: s.usage.tokens + tokens } })),
      resetAll: () => {
        try {
          localStorage.removeItem(KEY);
        } catch {}
        setState(EMPTY);
      },
    }),
    [state, ready, set]
  );

  return <AppCtx.Provider value={api}>{children}</AppCtx.Provider>;
}

export function useApp() {
  const c = useContext(AppCtx);
  if (!c) throw new Error("useApp must be used inside AppProvider");
  return c;
}

export function datasetRows(d: Dataset | undefined | null, mem?: Record<string, Row[]>): Row[] {
  if (!d) return [];
  if (d.source === "sample" && d.sampleId) return getSample(d.sampleId);
  return d.rows || mem?.[d.id] || [];
}

/** Active dataset rows + memoised profile */
export function useActiveDataset(): { dataset: Dataset | null; rows: Row[]; profile: DatasetProfile | null } {
  const { datasets, activeId } = useApp();
  const dataset = datasets.find((d) => d.id === activeId) || datasets[0] || null;
  const rows = useMemo(() => datasetRows(dataset), [dataset]);
  const profile = useMemo(() => (rows.length ? profileDataset(rows) : null), [rows]);
  return { dataset, rows, profile };
}
