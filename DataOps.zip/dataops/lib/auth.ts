/**
 * Client-side demo authentication.
 * Accounts are stored (with SHA-256 hashed passwords) in localStorage so the
 * project runs with zero backend cost. Swap this module for Supabase Auth or
 * NextAuth in production — the rest of the app only calls these functions.
 */
const KEY = "dataops:accounts";

interface Account { name: string; hash: string; provider: string; created: number }

function read(): Record<string, Account> {
  try { return JSON.parse(localStorage.getItem(KEY) || "{}"); } catch { return {}; }
}
function write(a: Record<string, Account>) {
  try { localStorage.setItem(KEY, JSON.stringify(a)); } catch {}
}

export async function hash(text: string) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode("dataops::" + text));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

export const isEmail = (e: string) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e.trim());

export function passwordStrength(p: string) {
  let s = 0;
  if (p.length >= 8) s++;
  if (p.length >= 12) s++;
  if (/[A-Z]/.test(p) && /[a-z]/.test(p)) s++;
  if (/\d/.test(p)) s++;
  if (/[^A-Za-z0-9]/.test(p)) s++;
  return Math.min(4, s); // 0..4
}

export async function register(name: string, email: string, password: string) {
  const e = email.trim().toLowerCase();
  const accounts = read();
  if (accounts[e]) throw new Error("An account with this email already exists. Try logging in.");
  accounts[e] = { name: name.trim(), hash: await hash(password), provider: "email", created: Date.now() };
  write(accounts);
  return { email: e, name: name.trim() };
}

export async function authenticate(email: string, password: string) {
  const e = email.trim().toLowerCase();
  const acc = read()[e];
  if (!acc) throw new Error("No account found for this email. Create one — it takes 10 seconds.");
  if (acc.provider !== "email") return { email: e, name: acc.name };
  if (acc.hash !== (await hash(password))) throw new Error("Incorrect password. Please try again.");
  return { email: e, name: acc.name };
}

export function socialSignIn(provider: string) {
  const email = `${provider}.user@dataops.app`;
  const accounts = read();
  if (!accounts[email]) {
    accounts[email] = { name: provider === "github" ? "GitHub User" : "Google User", hash: "", provider, created: Date.now() };
    write(accounts);
  }
  return { email, name: accounts[email].name };
}
