/**
 * DataOps local analysis engine.
 * Produces agent answers entirely in the browser from the real dataset,
 * so the product works with zero API keys. When GEMINI_API_KEY is set,
 * the /api/chat route is used instead and this acts as a fallback.
 */
import type { AgentId } from "./agents";
import type { Row } from "./sample-data";
import { DatasetProfile, groupBy, timeSeries, detectAnomalies, suggestCharts, label, fmtShort, correlation } from "./analytics";

export interface ChartSpec {
  type: "bar" | "line" | "donut" | "area";
  title: string;
  data: { name: string; value: number }[];
  valueLabel?: string;
}

export interface AgentReply {
  content: string;
  sql?: string;
  chart?: ChartSpec;
}

const q = (c: string) => "`" + c + "`";
const words = (s: string) => s.toLowerCase().replace(/[_-]/g, " ");

function mentioned(question: string, col: string) {
  const qs = words(question);
  const cw = words(col);
  if (qs.includes(cw)) return true;
  const parts = cw.split(" ").filter((p) => p.length > 3);
  // tolerate plurals: city → cities, category → categories, brand → brands
  return parts.some((p) => new RegExp(`\\b${p.endsWith("y") ? p.slice(0, -1) + "(?:y|ies)" : p + "(?:s|es)?"}\\b`).test(qs));
}

/* ------------------------------------------------------------------ */
/* Text-to-SQL (heuristic)                                              */
/* ------------------------------------------------------------------ */
export function textToSQL(question: string, p: DatasetProfile, rows: Row[]): string {
  const qs = question.toLowerCase();
  // Hinglish / Hindi superlatives: "sabse zyada" = most, "sabse kam" = least
  const hiMost = /(sabse (zyada|jyada|jada|adhik)|सबसे ज़्यादा|सबसे ज्यादा|सबसे अधिक)/.test(qs);
  const hiLeast = /(sabse kam|सबसे कम)/.test(qs);
  const topMatch = qs.match(/(top|bottom|best|worst|highest|lowest)\s*(\d+)?/);
  const n = topMatch?.[2] ? parseInt(topMatch[2]) : topMatch ? 5 : hiMost || hiLeast ? 1 : undefined;
  const asc = /(bottom|worst|lowest|least)/.test(qs) || hiLeast;

  let agg = "SUM";
  if (/(average|avg|mean|ausat|औसत)/.test(qs)) agg = "AVG";
  else if (/(maximum|max\b|highest single)/.test(qs)) agg = "MAX";
  else if (/(minimum|min\b)/.test(qs)) agg = "MIN";

  let metric = p.numeric.find((c) => mentioned(qs, c));
  const countIntent = /(how many|count|number of|orders\b|listings\b|volume|kitne|कितने)/.test(qs) && !metric;
  if (!metric && /(revenue|sales|income|money|gmv)/.test(qs)) metric = p.primaryMetric;
  if (!metric && !countIntent) metric = p.primaryMetric;

  const timeIntent = /(month|monthly|trend|over time|per month)/.test(qs);
  const dailyIntent = /(daily|per day|each day|by day)/.test(qs);
  const weekdayIntent = /(weekday|day of week)/.test(qs);

  // dimension
  const cats = p.cols.filter((c) => c.type === "category" || c.type === "text").map((c) => c.name);
  const byMatch = qs.match(/\b(?:by|per|for each|across|in each)\s+([a-z_ ]+)/);
  let dim = byMatch ? cats.find((c) => mentioned(byMatch[1], c)) : undefined;
  if (!dim) dim = cats.find((c) => mentioned(qs, c) && !(metric && c === metric));

  // filters: category values mentioned in question
  const filters: string[] = [];
  p.cols
    .filter((c) => c.type === "category" && c.top)
    .forEach((c) => {
      const all = new Set(rows.map((r) => r[c.name]).filter((v) => typeof v === "string"));
      const colWords = new Set(p.cols.flatMap((x) => words(x.name).split(" ")));
      for (const v of all as Set<string>) {
        if (colWords.has(v.toLowerCase())) continue; // e.g. a model called "City" vs the city column
        if (v.length > 2 && new RegExp(`\\b${v.toLowerCase().replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`).test(qs) && c.name !== dim) {
          filters.push(`${q(c.name)} = '${v.replace(/'/g, "''")}'`);
          break;
        }
      }
    });
  const where = filters.length ? `\nWHERE ${filters.join("\n  AND ")}` : "";
  const measure = countIntent || !metric ? "COUNT(*)" : `${agg === "AVG" ? "ROUND(AVG(" + q(metric) + "), 2)" : `${agg}(${q(metric)})`}`;
  const alias = countIntent || !metric ? "total_count" : `${agg.toLowerCase()}_${metric}`;

  if ((timeIntent || dailyIntent) && p.primaryDate) {
    const d = p.primaryDate;
    const expr = dailyIntent ? q(d) : `SUBSTRING(${q(d)}, 1, 7)`;
    const name = dailyIntent ? "day" : "month";
    return `SELECT ${expr} AS ${name},\n       ${measure} AS ${alias}\nFROM data${where}\nGROUP BY ${expr}\nORDER BY ${name} ASC`;
  }
  if (weekdayIntent && p.primaryDate) {
    return `SELECT DAYOFWEEK(${q(p.primaryDate)}) AS weekday,\n       ${measure} AS ${alias}\nFROM data${where}\nGROUP BY DAYOFWEEK(${q(p.primaryDate)})\nORDER BY weekday`;
  }
  if (dim) {
    return `SELECT ${q(dim)},\n       ${measure} AS ${alias}\nFROM data${where}\nGROUP BY ${q(dim)}\nORDER BY ${alias} ${asc ? "ASC" : "DESC"}${n ? `\nLIMIT ${n}` : ""}`;
  }
  if (n && metric) {
    return `SELECT *\nFROM data${where}\nORDER BY ${q(metric)} ${asc ? "ASC" : "DESC"}\nLIMIT ${n}`;
  }
  return `SELECT ${measure} AS ${alias}${metric && agg === "SUM" ? `,\n       ROUND(AVG(${q(metric)}), 2) AS avg_${metric},\n       COUNT(*) AS row_count` : ""}\nFROM data${where}`;
}

export function explainSQL(raw: string): string {
  const sql = raw.replace(/`/g, "");
  const b: string[] = [];
  const sel = sql.match(/SELECT([\s\S]*?)FROM/i)?.[1]?.trim().replace(/\s+/g, " ");
  if (sel) b.push(`**SELECT** picks \`${sel.length > 90 ? sel.slice(0, 90) + "…" : sel}\``);
  if (/WHERE/i.test(sql)) b.push(`**WHERE** filters rows to \`${sql.match(/WHERE([\s\S]*?)(GROUP|ORDER|LIMIT|$)/i)?.[1]?.trim().replace(/\s+/g, " ")}\``);
  if (/GROUP BY/i.test(sql)) b.push(`**GROUP BY** rolls rows up to one line per \`${sql.match(/GROUP BY\s+([^\n]+)/i)?.[1]}\``);
  if (/ORDER BY/i.test(sql)) b.push(`**ORDER BY** sorts the output by \`${sql.match(/ORDER BY\s+([^\n]+)/i)?.[1]}\``);
  if (/LIMIT/i.test(sql)) b.push(`**LIMIT** keeps only the first ${sql.match(/LIMIT\s+(\d+)/i)?.[1]} rows`);
  return b.map((x) => `- ${x}`).join("\n");
}

/* ------------------------------------------------------------------ */
/* Agent brains                                                         */
/* ------------------------------------------------------------------ */
function trendStats(rows: Row[], p: DatasetProfile) {
  if (!p.primaryDate || !p.primaryMetric) return null;
  const s = timeSeries(rows, p.primaryDate, p.primaryMetric, "month");
  if (s.length < 2) return null;
  const half = Math.floor(s.length / 2);
  const first = s.slice(0, half).reduce((a, b) => a + b.value, 0) / half;
  const second = s.slice(half).reduce((a, b) => a + b.value, 0) / (s.length - half);
  const best = [...s].sort((a, b) => b.value - a.value)[0];
  return { series: s, change: (second - first) / (first || 1), best };
}

function cleaner(rows: Row[], p: DatasetProfile): AgentReply {
  const grade = p.qualityScore >= 90 ? "Excellent" : p.qualityScore >= 75 ? "Good" : p.qualityScore >= 60 ? "Needs work" : "Poor";
  const issueLines = p.issues.slice(0, 8).map((i) => `| ${i.severity.toUpperCase()} | ${i.column ?? "—"} | ${i.title} | ${i.fix} |`);
  const missingCols = p.cols.filter((c) => c.missing).map((c) => c.name);
  const numMissing = p.cols.filter((c) => c.missing && c.type === "number").map((c) => c.name);
  const catMissing = p.cols.filter((c) => c.missing && c.type !== "number").map((c) => c.name);
  const content = `### Data Quality Report — ${p.qualityScore}/100 (${grade})
- **${p.rows.toLocaleString("en-IN")} rows × ${p.columns} columns** · ${p.missingCells} empty cells (${(p.missingPct * 100).toFixed(2)}%) · ${p.duplicates} duplicate rows
- Column types detected: ${p.numeric.length} numeric, ${p.categorical.length} categorical, ${p.dates.length} date

### Issues found
| Severity | Column | Issue | Recommended fix |
|---|---|---|---|
${issueLines.join("\n") || "| — | — | No issues found | — |"}

### Cleaning plan
1. **Remove duplicates** first so every later count is correct.
2. **Standardise text labels** (trim spaces, fix casing) in categorical columns.
3. **Handle missing values** — ${numMissing.length ? `median-impute ${numMissing.map((c) => `\`${c}\``).join(", ")}` : "no numeric gaps"}${catMissing.length ? `; fill ${catMissing.map((c) => `\`${c}\``).join(", ")} with mode / “Unknown”` : ""}.
4. **Treat outliers** — verify at source, then cap at P99 or analyse separately.
5. **Re-profile** and lock the cleaned file as your single source of truth.

### Do it in pandas
\`\`\`python
import pandas as pd
df = pd.read_csv("data.csv")
df = df.drop_duplicates()
${p.categorical.slice(0, 3).map((c) => `df["${c}"] = df["${c}"].str.strip().str.title()`).join("\n")}
${numMissing.map((c) => `df["${c}"] = df["${c}"].fillna(df["${c}"].median())`).join("\n")}
${catMissing.map((c) => `df["${c}"] = df["${c}"].fillna("Unknown")`).join("\n")}
\`\`\`
${missingCols.length === 0 && p.duplicates === 0 ? "\nThis dataset is already clean — you can go straight to analysis." : "\nTip: click **Auto-clean** on the Datasets page to apply this plan in one click."}`;
  return { content };
}

function viz(rows: Row[], p: DatasetProfile, question: string): AgentReply {
  const sug = suggestCharts(p);
  const secondary = [/rating|score|satisf/i, /minutes|time|days|duration/i, /price|cost/i].map((re) => p.numeric.find((n) => n !== p.primaryMetric && re.test(n))).find(Boolean) || p.numeric.find((n) => n !== p.primaryMetric);
  let chart: ChartSpec | undefined;
  const wantsTrend = /(trend|time|month|over)/i.test(question);
  if (wantsTrend && p.primaryDate && p.primaryMetric) {
    chart = { type: "area", title: `${label(p.primaryMetric)} by month`, data: timeSeries(rows, p.primaryDate, p.primaryMetric, "month").map((d) => ({ name: d.date, value: Math.round(d.value) })) };
  } else if (p.primaryDim && p.primaryMetric) {
    chart = { type: "bar", title: `${label(p.primaryMetric)} by ${label(p.primaryDim)}`, data: groupBy(rows, p.primaryDim, p.primaryMetric).slice(0, 10).map((d) => ({ name: d.name, value: Math.round(d.value) })) };
  }
  const content = `### Recommended visuals
${sug.map((s, i) => `${i + 1}. **${s.title}** — *${s.type}* chart (x: \`${s.x}\`${s.y ? `, y: \`${s.y}\`` : ""}). ${s.why}`).join("\n")}

### Dashboard layout (Power BI / Tableau ready)
- **Row 1 — KPI cards:** ${[p.primaryMetric && `Total ${label(p.primaryMetric)}`, "Row count", secondary && `Avg ${label(secondary)}`, "Data quality score"].filter(Boolean).join(" · ")}
- **Row 2 — Hero visual:** ${sug[0]?.title ?? "main trend"} (full width)
- **Row 3 — Supporting:** ${sug.slice(1, 3).map((s) => s.title).join(" + ") || "category breakdown"}
- **Slicers:** ${[p.primaryDate && "date range", ...p.categorical.slice(0, 3).map(label)].filter(Boolean).join(", ")}

### Design rules
- One highlight colour for the story, grey for context.
- Sort bars descending; start numeric axes at zero.
- Title every chart with the insight, not the metric (e.g. “Mumbai drives 24% of revenue”).
${chart ? "\nHere's the first one, built from your data 👇" : ""}`;
  return { content, chart };
}

function marketing(rows: Row[], p: DatasetProfile): AgentReply {
  const metric = p.primaryMetric;
  const segCols = p.cols.filter((c) => c.type === "category" && c.unique >= 2 && c.unique <= 12).map((c) => c.name);
  const lines: string[] = [];
  let chart: ChartSpec | undefined;
  const total = metric ? rows.reduce((s, r) => s + (Number(r[metric]) || 0), 0) : rows.length;

  segCols.slice(0, 3).forEach((c, idx) => {
    const g = groupBy(rows, c, metric);
    const top = g[0];
    const share = top ? top.value / (total || 1) : 0;
    const avg = groupBy(rows, c, metric, "avg");
    const bestAvg = avg[0];
    lines.push(`- **${label(c)}:** “${top?.name}” contributes **${(share * 100).toFixed(1)}%** of ${metric ? label(metric).toLowerCase() : "rows"}; highest average ticket is “${bestAvg?.name}” (${fmtShort(bestAvg?.value ?? 0)}).`);
    if (idx === 0) chart = { type: "donut", title: `${metric ? label(metric) : "Rows"} share by ${label(c)}`, data: g.slice(0, 6).map((d) => ({ name: d.name, value: Math.round(d.value) })) };
  });

  // campaign style metrics
  const has = (n: string) => p.numeric.includes(n);
  let campaign = "";
  if (has("spend") && has("revenue")) {
    const dim = p.categorical.find((c) => /channel/i.test(c)) || p.categorical[0];
    const spend = groupBy(rows, dim, "spend");
    const rev = new Map(groupBy(rows, dim, "revenue").map((d) => [d.name, d.value]));
    const conv = has("conversions") ? new Map(groupBy(rows, dim, "conversions").map((d) => [d.name, d.value])) : null;
    const tbl = spend
      .map((s) => ({ name: s.name, spend: s.value, rev: rev.get(s.name) || 0, cac: conv ? s.value / (conv.get(s.name) || 1) : 0 }))
      .map((x) => ({ ...x, roas: x.rev / (x.spend || 1) }))
      .sort((a, b) => b.roas - a.roas);
    campaign = `\n### Channel efficiency (${label(dim)})
| ${label(dim)} | Spend | Revenue | ROAS | ${conv ? "CAC |" : ""}
|---|---|---|---|${conv ? "---|" : ""}
${tbl.map((t) => `| ${t.name} | ₹${fmtShort(t.spend)} | ₹${fmtShort(t.rev)} | **${t.roas.toFixed(2)}x** | ${conv ? `₹${t.cac.toFixed(0)} |` : ""}`).join("\n")}

**Shift budget** from **${tbl[tbl.length - 1].name}** (${tbl[tbl.length - 1].roas.toFixed(1)}x) toward **${tbl[0].name}** (${tbl[0].roas.toFixed(1)}x).`;
    chart = { type: "bar", title: `ROAS by ${label(dim)}`, data: tbl.map((t) => ({ name: t.name, value: Math.round(t.roas * 100) / 100 })), valueLabel: "x" };
  }

  const custCol = p.categorical.find((c) => /customer|segment|type|tier/i.test(c));
  const retention = custCol
    ? (() => {
        const g = groupBy(rows, custCol, metric);
        const avg = groupBy(rows, custCol, metric, "avg");
        return `\n### Customer mix (${label(custCol)})\n${g.map((x) => `- **${x.name}**: ${(x.value / (total || 1) * 100).toFixed(1)}% of value · avg ${fmtShort(avg.find((a) => a.name === x.name)?.value ?? 0)} per order`).join("\n")}`;
      })()
    : "";

  const content = `### Segmentation snapshot
${lines.join("\n") || "- Not enough categorical columns to segment — add a customer or region column."}
${retention}${campaign}

### Recommended plays
1. **Protect the core** — build a loyalty offer for the top segment above; they carry the revenue.
2. **Grow the tail** — target the lowest-share segment with a first-order discount and measure CAC vs AOV.
3. **Test weekly** — run one A/B test per week on offer, channel or timing; track **conversion rate, AOV, repeat rate (30-day) and ROAS**.

### RFM starter (SQL)
\`\`\`sql
SELECT customer_id,
       DATEDIFF(day, MAX(order_date), CURRENT_DATE) AS recency,
       COUNT(*)                                    AS frequency,
       SUM(${metric ?? "amount"})                  AS monetary
FROM orders
GROUP BY customer_id;
\`\`\``;
  return { content, chart };
}

function advisor(rows: Row[], p: DatasetProfile): AgentReply {
  const m = p.primaryMetric;
  const total = m ? rows.reduce((s, r) => s + (Number(r[m]) || 0), 0) : 0;
  const t = trendStats(rows, p);
  const dim = p.primaryDim;
  const g = dim && m ? groupBy(rows, dim, m).filter((x) => x.name !== "Unknown") : [];
  const top = g[0],
    bottom = g[g.length - 1];
  const money = m && /revenue|sales|amount|price|spend|gmv|profit|cost|value/i.test(m) ? "₹" : "";
  const daily = p.primaryDate && m ? timeSeries(rows, p.primaryDate, m, "day") : [];
  const anomalies = detectAnomalies(daily);
  const secondNum = p.numeric.find((n) => n !== m && !/id|price/i.test(n));
  const corr = secondNum && m ? correlation(rows, secondNum, m) : 0;
  const ratingCol = p.numeric.find((n) => /rating|score|satisf/i.test(n));
  const deliveryCol = p.numeric.find((n) => /deliver|time|minutes|days/i.test(n));
  const rdCorr = ratingCol && deliveryCol ? correlation(rows, deliveryCol, ratingCol) : 0;

  const summary = [
    m && `Total **${label(m).toLowerCase()} is ${money}${fmtShort(total)}** across ${p.rows.toLocaleString("en-IN")} records.`,
    t && `Momentum is **${t.change >= 0 ? "up" : "down"} ${(Math.abs(t.change) * 100).toFixed(1)}%** (second half vs first half); best month was **${t.best.date}**.`,
    top && `**${top.name}** leads ${label(dim!).toLowerCase()} with ${((top.value / (total || 1)) * 100).toFixed(1)}% share; **${bottom.name}** trails at ${((bottom.value / (total || 1)) * 100).toFixed(1)}%.`,
    anomalies.length && `Anomaly Watch flagged **${anomalies.length} unusual days** — biggest: ${anomalies.sort((a, b) => Math.abs(b.z) - Math.abs(a.z))[0].date} (${anomalies[0].direction}).`,
    `Data quality score is **${p.qualityScore}/100**${p.issues.length ? ` with ${p.issues.length} open issues` : ""}.`,
  ].filter(Boolean);

  const insights: string[] = [];
  if (Math.abs(rdCorr) > 0.15) insights.push(`\`${deliveryCol}\` and \`${ratingCol}\` are ${rdCorr < 0 ? "negatively" : "positively"} correlated (r = ${rdCorr.toFixed(2)}) — ${rdCorr < 0 ? "slower service is costing you ratings" : "worth investigating"}.`);
  if (secondNum && Math.abs(corr) > 0.3) insights.push(`\`${secondNum}\` moves with \`${m}\` (r = ${corr.toFixed(2)}) — a useful lever to forecast from.`);
  if (g.length > 3) {
    const top3 = g.slice(0, 3).reduce((s, x) => s + x.value, 0) / (total || 1);
    insights.push(`Top 3 ${label(dim!).toLowerCase()} values make up **${(top3 * 100).toFixed(0)}%** of ${label(m!).toLowerCase()} — ${top3 > 0.6 ? "high concentration risk" : "healthy spread"}.`);
  }

  const content = `### Executive summary
${summary.map((s) => `- ${s}`).join("\n")}

### Key insights
${insights.map((s) => `- ${s}`).join("\n") || "- Add more numeric columns for deeper driver analysis."}

### Top 3 recommendations
1. **Double down on ${top?.name ?? "the leading segment"}** — replicate what works there (assortment, pricing, ops) in ${bottom?.name ?? "weaker segments"}. *Impact: high · Effort: medium*
2. **${anomalies.length ? "Set alerting on the metrics Anomaly Watch flagged" : "Set weekly KPI monitoring"}** — catch stock-outs, outages and promo spikes within hours, not weeks. *Impact: high · Effort: low*
3. **${p.qualityScore < 90 ? "Fix data quality at the source" : Math.abs(rdCorr) > 0.15 ? `Improve ${label(deliveryCol!).toLowerCase()}` : "Launch a retention experiment"}** — ${p.qualityScore < 90 ? "every decision above is only as good as the data under it." : "small operational gains compound into rating and repeat-order growth."} *Impact: medium · Effort: low*

### KPIs to track weekly
${[m && `Total ${label(m)}`, m && `Avg ${label(m)} per order`, ratingCol && `Avg ${label(ratingCol)}`, deliveryCol && `P90 ${label(deliveryCol)}`, "Anomaly count", "Data quality score"].filter(Boolean).map((k) => `- ${k}`).join("\n")}`;
  const chart: ChartSpec | undefined = t ? { type: "area", title: `${label(m!)} trend (monthly)`, data: t.series.map((d) => ({ name: d.date, value: Math.round(d.value) })) } : undefined;
  return { content, chart };
}

export function localAgentReply(agent: AgentId, question: string, rows: Row[] | null, p: DatasetProfile | null): AgentReply {
  if (!rows || !p || !rows.length) {
    return {
      content: `### Let's get some data in first
I work best with a dataset. Head to **Datasets** and either:
- upload a **CSV / Excel-exported CSV**, or
- load one of the **sample datasets** (Quick-Commerce Orders is a great start).

Then come back and ask me anything — I'll ${agent === "sql" ? "write and run SQL for you" : "analyse it for you"}.`,
    };
  }
  switch (agent) {
    case "cleaner":
      return cleaner(rows, p);
    case "viz":
      return viz(rows, p, question);
    case "marketing":
      return marketing(rows, p);
    case "advisor":
      return advisor(rows, p);
    case "sql": {
      const sql = textToSQL(question, p, rows);
      return { content: `Here's the query for: *${question}*\n\n\`\`\`sql\n${sql}\n\`\`\`\n\n${explainSQL(sql)}`, sql };
    }
  }
}

/** Compact profile summary sent to the LLM as context */
export function profileContext(name: string, p: DatasetProfile, rows: Row[]) {
  const cols = p.cols
    .map((c) => {
      if (c.type === "number") return `- ${c.name} (number): mean ${fmtShort(c.mean!)}, median ${fmtShort(c.median!)}, min ${fmtShort(c.min!)}, max ${fmtShort(c.max!)}, missing ${c.missing}, outliers ${c.outliers}`;
      if (c.type === "date") return `- ${c.name} (date): ${c.minDate} → ${c.maxDate}, missing ${c.missing}`;
      return `- ${c.name} (${c.type}): ${c.unique} unique, missing ${c.missing}${c.top ? `, top: ${c.top.slice(0, 5).map((t) => `${t.value} (${t.count})`).join(", ")}` : ""}${c.inconsistentCase ? `, ${c.inconsistentCase} inconsistent labels` : ""}`;
    })
    .join("\n");
  const extra: string[] = [];
  if (p.primaryDim && p.primaryMetric) extra.push(`${p.primaryMetric} by ${p.primaryDim}: ` + groupBy(rows, p.primaryDim, p.primaryMetric).slice(0, 8).map((g) => `${g.name}=${fmtShort(g.value)}`).join(", "));
  if (p.primaryDate && p.primaryMetric) extra.push(`${p.primaryMetric} by month: ` + timeSeries(rows, p.primaryDate, p.primaryMetric, "month").map((g) => `${g.date}=${fmtShort(g.value)}`).join(", "));
  return `Dataset "${name}": ${p.rows} rows, ${p.columns} columns, ${p.duplicates} duplicate rows, quality score ${p.qualityScore}/100.
Columns:
${cols}
${extra.join("\n")}`;
}
