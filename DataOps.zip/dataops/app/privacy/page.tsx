import { PageShell } from "@/components/landing/PageShell";
import { Markdown } from "@/components/Markdown";

export const metadata = { title: "Privacy Policy — DataOps" };

const BODY = `### What we collect
- **Account details** you provide: name, email, role.
- **Usage data**: number of questions asked and features used, to improve the product.

### Your data files
- CSV files are parsed **in your browser**. Raw rows are not uploaded to DataOps servers.
- When you chat with an agent, a compact statistical profile (column names, types, counts, averages, top categories) is sent to the AI provider to generate an answer.

### Storage
- Workspace data is stored in your browser's local storage. You can delete it anytime from **Settings → Reset workspace**.

### Contact
Questions? Email hello@dataops.app.`;

export default function Page() {
  return (
    <PageShell eyebrow="Legal" title="Privacy Policy" sub="Last updated: September 2026">
      <div className="card mx-auto max-w-3xl p-8"><Markdown text={BODY} /></div>
    </PageShell>
  );
}
