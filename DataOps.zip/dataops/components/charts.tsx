"use client";

import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Line, LineChart, Pie, PieChart,
  ResponsiveContainer, Scatter, ScatterChart, Tooltip, XAxis, YAxis, ReferenceDot,
} from "recharts";
import type { ChartSpec } from "@/lib/local-engine";
import { fmtShort } from "@/lib/analytics";
import { AXIS, GRID, PRIMARY, SERIES } from "@/lib/palette";

const tick = { fill: AXIS, fontSize: 11 };

export function TooltipBox({ active, payload, label, suffix = "" }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-xl border border-white/10 bg-ink-900/95 px-3 py-2 text-xs shadow-2xl backdrop-blur">
      {label !== undefined && <div className="mb-1 font-mono text-[11px] text-mute">{label}</div>}
      {payload.map((p: any, i: number) => (
        <div key={i} className="flex items-center gap-2 text-white">
          <span className="h-2 w-2 rounded-full" style={{ background: p.color || p.payload?.fill || PRIMARY }} />
          <span className="text-white/70">{p.name}</span>
          <span className="ml-auto font-medium tabular-nums">{typeof p.value === "number" ? fmtShort(p.value) : p.value}{suffix}</span>
        </div>
      ))}
    </div>
  );
}

export function TrendArea({ data, height = 260, dataKey = "value", xKey = "name", name = "Value", anomalies }: { data: any[]; height?: number; dataKey?: string; xKey?: string; name?: string; anomalies?: { x: string; y: number; kind: "spike" | "drop" }[] }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart data={data} margin={{ top: 10, right: 8, left: -12, bottom: 0 }}>
        <defs>
          <linearGradient id="areaFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={PRIMARY} stopOpacity={0.28} />
            <stop offset="100%" stopColor={PRIMARY} stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid stroke={GRID} vertical={false} />
        <XAxis dataKey={xKey} tick={tick} tickLine={false} axisLine={false} minTickGap={28} />
        <YAxis tick={tick} tickLine={false} axisLine={false} tickFormatter={(v) => fmtShort(v)} width={56} />
        <Tooltip content={<TooltipBox />} cursor={{ stroke: "rgba(255,255,255,.25)", strokeDasharray: "3 3" }} />
        <Area type="monotone" dataKey={dataKey} name={name} stroke={PRIMARY} strokeWidth={2} fill="url(#areaFill)" activeDot={{ r: 5, strokeWidth: 2, stroke: "#0A0D18" }} />
        {anomalies?.map((a, i) => (
          <ReferenceDot key={i} x={a.x} y={a.y} r={6} fill={a.kind === "spike" ? "#FFB547" : "#FF5C5C"} stroke="#0A0D18" strokeWidth={2} />
        ))}
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function RankedBars({ data, height = 260, name = "Value", horizontal = true, suffix = "" }: { data: { name: string; value: number }[]; height?: number; name?: string; horizontal?: boolean; suffix?: string }) {
  if (horizontal) {
    return (
      <ResponsiveContainer width="100%" height={height}>
        <BarChart data={data} layout="vertical" margin={{ top: 4, right: 16, left: 4, bottom: 0 }} barCategoryGap={6}>
          <CartesianGrid stroke={GRID} horizontal={false} />
          <XAxis type="number" tick={tick} tickLine={false} axisLine={false} tickFormatter={(v) => fmtShort(v)} />
          <YAxis type="category" dataKey="name" tick={{ ...tick, fill: "#aab2c4" }} tickLine={false} axisLine={false} width={110} />
          <Tooltip content={<TooltipBox suffix={suffix} />} cursor={{ fill: "rgba(255,255,255,.04)" }} />
          <Bar dataKey="value" name={name} fill={PRIMARY} radius={[0, 4, 4, 0]} maxBarSize={22} />
        </BarChart>
      </ResponsiveContainer>
    );
  }
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 10, right: 8, left: -12, bottom: 0 }}>
        <CartesianGrid stroke={GRID} vertical={false} />
        <XAxis dataKey="name" tick={tick} tickLine={false} axisLine={false} interval={0} />
        <YAxis tick={tick} tickLine={false} axisLine={false} tickFormatter={(v) => fmtShort(v)} width={56} />
        <Tooltip content={<TooltipBox suffix={suffix} />} cursor={{ fill: "rgba(255,255,255,.04)" }} />
        <Bar dataKey="value" name={name} fill={PRIMARY} radius={[4, 4, 0, 0]} maxBarSize={36} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function Donut({ data, height = 240 }: { data: { name: string; value: number }[]; height?: number }) {
  // fold beyond 5 into "Other" so we never exceed the fixed palette
  const d = data.length > 6 ? [...data.slice(0, 5), { name: "Other", value: data.slice(5).reduce((s, x) => s + x.value, 0) }] : data;
  const total = d.reduce((s, x) => s + x.value, 0) || 1;
  return (
    <div className="flex flex-col items-center gap-4 sm:flex-row">
      <div style={{ width: height, height }} className="relative shrink-0">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Tooltip content={<TooltipBox />} />
            <Pie data={d} dataKey="value" nameKey="name" innerRadius="62%" outerRadius="92%" paddingAngle={2} stroke="#0A0D18" strokeWidth={2}>
              {d.map((_, i) => <Cell key={i} fill={SERIES[i % SERIES.length]} />)}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-[11px] uppercase tracking-wider text-mute">Total</span>
          <span className="text-lg font-semibold tabular-nums">{fmtShort(total)}</span>
        </div>
      </div>
      <ul className="w-full space-y-1.5 text-xs">
        {d.map((x, i) => (
          <li key={x.name} className="flex items-center gap-2">
            <span className="h-2.5 w-2.5 shrink-0 rounded-sm" style={{ background: SERIES[i % SERIES.length] }} />
            <span className="truncate text-white/80">{x.name}</span>
            <span className="ml-auto tabular-nums text-white">{((x.value / total) * 100).toFixed(1)}%</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function Histogram({ data, height = 200 }: { data: { bin: string; count: number }[]; height?: number }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 6, right: 4, left: 0, bottom: 0 }} barCategoryGap={2}>
        <CartesianGrid stroke={GRID} vertical={false} />
        <XAxis dataKey="bin" tick={tick} tickLine={false} axisLine={false} interval={1} />
        <YAxis tick={tick} tickLine={false} axisLine={false} width={34} tickFormatter={(v) => fmtShort(v)} />
        <Tooltip content={<TooltipBox />} cursor={{ fill: "rgba(255,255,255,.04)" }} />
        <Bar dataKey="count" name="Rows" fill={PRIMARY} radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function ScatterPlot({ data, x, y, height = 260 }: { data: any[]; x: string; y: string; height?: number }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <ScatterChart margin={{ top: 10, right: 8, left: -12, bottom: 0 }}>
        <CartesianGrid stroke={GRID} />
        <XAxis type="number" dataKey={x} name={x} tick={tick} tickLine={false} axisLine={false} tickFormatter={(v) => fmtShort(v)} />
        <YAxis type="number" dataKey={y} name={y} tick={tick} tickLine={false} axisLine={false} tickFormatter={(v) => fmtShort(v)} width={56} />
        <Tooltip content={<TooltipBox />} cursor={{ strokeDasharray: "3 3", stroke: "rgba(255,255,255,.2)" }} />
        <Scatter data={data} fill={PRIMARY} fillOpacity={0.55} stroke="#0A0D18" strokeWidth={1} />
      </ScatterChart>
    </ResponsiveContainer>
  );
}

export function Sparkline({ data, color = PRIMARY, height = 40 }: { data: number[]; color?: string; height?: number }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={data.map((v, i) => ({ i, v }))} margin={{ top: 4, bottom: 4, left: 0, right: 0 }}>
        <Line type="monotone" dataKey="v" stroke={color} strokeWidth={2} dot={false} isAnimationActive={false} />
      </LineChart>
    </ResponsiveContainer>
  );
}

export function SpecChart({ spec }: { spec: ChartSpec }) {
  return (
    <div className="mt-3 rounded-xl border border-white/10 bg-ink-950/60 p-3">
      <div className="mb-2 text-xs font-medium text-white/80">{spec.title}</div>
      {spec.type === "donut" ? (
        <Donut data={spec.data} height={180} />
      ) : spec.type === "area" || spec.type === "line" ? (
        <TrendArea data={spec.data} height={220} />
      ) : (
        <RankedBars data={spec.data} height={Math.max(160, spec.data.length * 30)} suffix={spec.valueLabel} />
      )}
    </div>
  );
}
